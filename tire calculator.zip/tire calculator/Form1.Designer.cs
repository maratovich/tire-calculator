﻿namespace TyreCalculator
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.ListViewItem listViewItem19 = new System.Windows.Forms.ListViewItem(new string[] {
            "Диаметр",
            "",
            "",
            ""}, -1, System.Drawing.Color.Empty, System.Drawing.Color.Empty, new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204))));
            System.Windows.Forms.ListViewItem listViewItem20 = new System.Windows.Forms.ListViewItem(new string[] {
            "Ширина",
            "",
            "",
            ""}, -1, System.Drawing.Color.Empty, System.Drawing.Color.Empty, new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204))));
            System.Windows.Forms.ListViewItem listViewItem21 = new System.Windows.Forms.ListViewItem(new string[] {
            "Длина окружности",
            "",
            "",
            ""}, -1, System.Drawing.Color.Empty, System.Drawing.Color.Empty, new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204))));
            System.Windows.Forms.ListViewItem listViewItem22 = new System.Windows.Forms.ListViewItem(new string[] {
            "Высота профиля",
            "",
            "",
            ""}, -1, System.Drawing.Color.Empty, System.Drawing.Color.Empty, new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204))));
            System.Windows.Forms.ListViewItem listViewItem23 = new System.Windows.Forms.ListViewItem(new string[] {
            "Оборотов на км",
            "",
            "",
            ""}, -1, System.Drawing.Color.Empty, System.Drawing.Color.Empty, new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204))));
            System.Windows.Forms.ListViewItem listViewItem24 = new System.Windows.Forms.ListViewItem(new string[] {
            "Изменение клиренса\t",
            ""}, -1, System.Drawing.Color.Empty, System.Drawing.Color.Empty, new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204))));
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label6 = new System.Windows.Forms.Label();
            this.newProfileComboBox = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.newWidthComboBox = new System.Windows.Forms.ComboBox();
            this.newWheelSizeComboBox = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.profileComboBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.widthComboBox = new System.Windows.Forms.ComboBox();
            this.wheelSizeComboBox = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.clearButton = new System.Windows.Forms.Button();
            this.addButton = new System.Windows.Forms.Button();
            this.yearComboBox = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.engineComboBox = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.modelComboBox = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.brandComboBox = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listView2 = new System.Windows.Forms.ListView();
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.settingslStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dictionarySetStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveConfStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.savePdftoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.labelSpeed10 = new System.Windows.Forms.Label();
            this.labelSpeed20 = new System.Windows.Forms.Label();
            this.labelSpeed30 = new System.Windows.Forms.Label();
            this.labelSpeed40 = new System.Windows.Forms.Label();
            this.labelSpeed50 = new System.Windows.Forms.Label();
            this.labelSpeed60 = new System.Windows.Forms.Label();
            this.labelSpeed70 = new System.Windows.Forms.Label();
            this.labelSpeed80 = new System.Windows.Forms.Label();
            this.labelSpeed90 = new System.Windows.Forms.Label();
            this.labelSpeed100 = new System.Windows.Forms.Label();
            this.labelSpeed110 = new System.Windows.Forms.Label();
            this.labelSpeed120 = new System.Windows.Forms.Label();
            this.labelSpeed130 = new System.Windows.Forms.Label();
            this.labelSpeed140 = new System.Windows.Forms.Label();
            this.labelSpeed150 = new System.Windows.Forms.Label();
            this.labelSpeed160 = new System.Windows.Forms.Label();
            this.labelSpeed170 = new System.Windows.Forms.Label();
            this.labelSpeed180 = new System.Windows.Forms.Label();
            this.titleLabelSpeed = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(12, 316);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(406, 300);
            this.pictureBox1.TabIndex = 21;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox1_Paint);
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(93, 325);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 23);
            this.label7.TabIndex = 22;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Показатели";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Старая разм-ть";
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Новая разм-ть";
            // 
            // listView1
            // 
            this.listView1.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader13});
            this.listView1.GridLines = true;
            this.listView1.HoverSelection = true;
            this.listView1.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem19,
            listViewItem20,
            listViewItem21,
            listViewItem22,
            listViewItem23,
            listViewItem24});
            this.listView1.Location = new System.Drawing.Point(14, 171);
            this.listView1.MultiSelect = false;
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(404, 132);
            this.listView1.TabIndex = 23;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "Разница показаний";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(143, 17);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(92, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "Высота профиля";
            // 
            // newProfileComboBox
            // 
            this.newProfileComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.newProfileComboBox.FormattingEnabled = true;
            this.newProfileComboBox.Location = new System.Drawing.Point(136, 33);
            this.newProfileComboBox.Name = "newProfileComboBox";
            this.newProfileComboBox.Size = new System.Drawing.Size(121, 21);
            this.newProfileComboBox.Sorted = true;
            this.newProfileComboBox.TabIndex = 17;
            this.newProfileComboBox.SelectedIndexChanged += new System.EventHandler(this.CmbBox_Change);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 15);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "Ширина профиля";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(276, 17);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(116, 13);
            this.label4.TabIndex = 18;
            this.label4.Text = "Посадочный диаметр";
            // 
            // newWidthComboBox
            // 
            this.newWidthComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.newWidthComboBox.FormattingEnabled = true;
            this.newWidthComboBox.Location = new System.Drawing.Point(6, 33);
            this.newWidthComboBox.Name = "newWidthComboBox";
            this.newWidthComboBox.Size = new System.Drawing.Size(121, 21);
            this.newWidthComboBox.Sorted = true;
            this.newWidthComboBox.TabIndex = 15;
            this.newWidthComboBox.SelectedIndexChanged += new System.EventHandler(this.CmbBox_Change);
            // 
            // newWheelSizeComboBox
            // 
            this.newWheelSizeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.newWheelSizeComboBox.FormattingEnabled = true;
            this.newWheelSizeComboBox.Location = new System.Drawing.Point(271, 33);
            this.newWheelSizeComboBox.Name = "newWheelSizeComboBox";
            this.newWheelSizeComboBox.Size = new System.Drawing.Size(121, 21);
            this.newWheelSizeComboBox.Sorted = true;
            this.newWheelSizeComboBox.TabIndex = 19;
            this.newWheelSizeComboBox.SelectedIndexChanged += new System.EventHandler(this.CmbBox_Change);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.newWheelSizeComboBox);
            this.groupBox2.Controls.Add(this.newWidthComboBox);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.newProfileComboBox);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Location = new System.Drawing.Point(12, 97);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(406, 64);
            this.groupBox2.TabIndex = 20;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Новая размерность";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(143, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 13);
            this.label2.TabIndex = 16;
            this.label2.Text = "Высота профиля";
            // 
            // profileComboBox
            // 
            this.profileComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.profileComboBox.FormattingEnabled = true;
            this.profileComboBox.Location = new System.Drawing.Point(136, 32);
            this.profileComboBox.Name = "profileComboBox";
            this.profileComboBox.Size = new System.Drawing.Size(121, 21);
            this.profileComboBox.Sorted = true;
            this.profileComboBox.TabIndex = 17;
            this.profileComboBox.SelectedIndexChanged += new System.EventHandler(this.CmbBox_Change);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "Ширина профиля";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(276, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(116, 13);
            this.label3.TabIndex = 18;
            this.label3.Text = "Посадочный диаметр";
            // 
            // widthComboBox
            // 
            this.widthComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.widthComboBox.FormattingEnabled = true;
            this.widthComboBox.Location = new System.Drawing.Point(6, 33);
            this.widthComboBox.Name = "widthComboBox";
            this.widthComboBox.Size = new System.Drawing.Size(121, 21);
            this.widthComboBox.Sorted = true;
            this.widthComboBox.TabIndex = 15;
            this.widthComboBox.SelectedIndexChanged += new System.EventHandler(this.CmbBox_Change);
            // 
            // wheelSizeComboBox
            // 
            this.wheelSizeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.wheelSizeComboBox.FormattingEnabled = true;
            this.wheelSizeComboBox.Location = new System.Drawing.Point(271, 33);
            this.wheelSizeComboBox.Name = "wheelSizeComboBox";
            this.wheelSizeComboBox.Size = new System.Drawing.Size(121, 21);
            this.wheelSizeComboBox.Sorted = true;
            this.wheelSizeComboBox.TabIndex = 19;
            this.wheelSizeComboBox.SelectedIndexChanged += new System.EventHandler(this.CmbBox_Change);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox1.Controls.Add(this.wheelSizeComboBox);
            this.groupBox1.Controls.Add(this.widthComboBox);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.profileComboBox);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(12, 27);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(406, 64);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Старая размерность";
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Разница";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.clearButton);
            this.groupBox3.Controls.Add(this.addButton);
            this.groupBox3.Controls.Add(this.yearComboBox);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.engineComboBox);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.modelComboBox);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.brandComboBox);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Location = new System.Drawing.Point(439, 27);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(438, 134);
            this.groupBox3.TabIndex = 24;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Подбор по марке и модели авто";
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(263, 82);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(118, 23);
            this.clearButton.TabIndex = 28;
            this.clearButton.Text = "Очистить";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // addButton
            // 
            this.addButton.Enabled = false;
            this.addButton.Location = new System.Drawing.Point(136, 82);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(118, 23);
            this.addButton.TabIndex = 26;
            this.addButton.Text = "Добавить";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // yearComboBox
            // 
            this.yearComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.yearComboBox.FormattingEnabled = true;
            this.yearComboBox.Location = new System.Drawing.Point(260, 33);
            this.yearComboBox.Name = "yearComboBox";
            this.yearComboBox.Size = new System.Drawing.Size(121, 21);
            this.yearComboBox.Sorted = true;
            this.yearComboBox.TabIndex = 27;
            this.yearComboBox.SelectedIndexChanged += new System.EventHandler(this.yearComboBox_SelectedIndexChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(260, 17);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(71, 13);
            this.label11.TabIndex = 26;
            this.label11.Text = "Год выпуска";
            // 
            // engineComboBox
            // 
            this.engineComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.engineComboBox.FormattingEnabled = true;
            this.engineComboBox.Location = new System.Drawing.Point(6, 82);
            this.engineComboBox.Name = "engineComboBox";
            this.engineComboBox.Size = new System.Drawing.Size(121, 21);
            this.engineComboBox.Sorted = true;
            this.engineComboBox.TabIndex = 25;
            this.engineComboBox.SelectedIndexChanged += new System.EventHandler(this.engineComboBox_SelectedIndexChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 65);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(62, 13);
            this.label10.TabIndex = 24;
            this.label10.Text = "Двигатель";
            // 
            // modelComboBox
            // 
            this.modelComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.modelComboBox.FormattingEnabled = true;
            this.modelComboBox.Location = new System.Drawing.Point(133, 33);
            this.modelComboBox.Name = "modelComboBox";
            this.modelComboBox.Size = new System.Drawing.Size(121, 21);
            this.modelComboBox.Sorted = true;
            this.modelComboBox.TabIndex = 23;
            this.modelComboBox.SelectedIndexChanged += new System.EventHandler(this.modelComboBox_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(133, 17);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(46, 13);
            this.label9.TabIndex = 22;
            this.label9.Text = "Модель";
            // 
            // brandComboBox
            // 
            this.brandComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.brandComboBox.FormattingEnabled = true;
            this.brandComboBox.Location = new System.Drawing.Point(6, 33);
            this.brandComboBox.Name = "brandComboBox";
            this.brandComboBox.Size = new System.Drawing.Size(121, 21);
            this.brandComboBox.Sorted = true;
            this.brandComboBox.TabIndex = 21;
            this.brandComboBox.SelectedIndexChanged += new System.EventHandler(this.brandComboBox_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 17);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(40, 13);
            this.label8.TabIndex = 20;
            this.label8.Text = "Марка";
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Марка";
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Модель";
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Года выпуска";
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Двигатель";
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Размерность шин 1";
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Размерность шин 2";
            // 
            // listView2
            // 
            this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader12});
            this.listView2.GridLines = true;
            this.listView2.Location = new System.Drawing.Point(439, 171);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(438, 132);
            this.listView2.TabIndex = 25;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Размерность шин 3";
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Размерность шин 3";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.settingslStripMenuItem,
            this.aboutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(884, 24);
            this.menuStrip1.TabIndex = 30;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // settingslStripMenuItem
            // 
            this.settingslStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dictionarySetStripMenuItem,
            this.saveConfStripMenuItem,
            this.savePdftoolStripMenuItem});
            this.settingslStripMenuItem.Name = "settingslStripMenuItem";
            this.settingslStripMenuItem.Size = new System.Drawing.Size(79, 20);
            this.settingslStripMenuItem.Text = "Настройки";
            // 
            // dictionarySetStripMenuItem
            // 
            this.dictionarySetStripMenuItem.Name = "dictionarySetStripMenuItem";
            this.dictionarySetStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.dictionarySetStripMenuItem.Text = "Редактор справочников";
            this.dictionarySetStripMenuItem.Click += new System.EventHandler(this.dictionarySetStripMenuItem_Click);
            // 
            // saveConfStripMenuItem
            // 
            this.saveConfStripMenuItem.Name = "saveConfStripMenuItem";
            this.saveConfStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.saveConfStripMenuItem.Text = "Сохранить параметры";
            // 
            // savePdftoolStripMenuItem
            // 
            this.savePdftoolStripMenuItem.Name = "savePdftoolStripMenuItem";
            this.savePdftoolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.savePdftoolStripMenuItem.Text = "Сохранить в *.Pdf";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(94, 20);
            this.aboutToolStripMenuItem.Text = "О программе";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Location = new System.Drawing.Point(439, 316);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(300, 300);
            this.pictureBox2.TabIndex = 31;
            this.pictureBox2.TabStop = false;
            // 
            // labelSpeed10
            // 
            this.labelSpeed10.AutoSize = true;
            this.labelSpeed10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelSpeed10.ForeColor = System.Drawing.Color.DarkRed;
            this.labelSpeed10.Location = new System.Drawing.Point(456, 511);
            this.labelSpeed10.Name = "labelSpeed10";
            this.labelSpeed10.Size = new System.Drawing.Size(23, 15);
            this.labelSpeed10.TabIndex = 32;
            this.labelSpeed10.Tag = "";
            this.labelSpeed10.Text = "10";
            // 
            // labelSpeed20
            // 
            this.labelSpeed20.AutoSize = true;
            this.labelSpeed20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelSpeed20.ForeColor = System.Drawing.Color.DarkRed;
            this.labelSpeed20.Location = new System.Drawing.Point(445, 487);
            this.labelSpeed20.Name = "labelSpeed20";
            this.labelSpeed20.Size = new System.Drawing.Size(23, 15);
            this.labelSpeed20.TabIndex = 33;
            this.labelSpeed20.Tag = "";
            this.labelSpeed20.Text = "20";
            // 
            // labelSpeed30
            // 
            this.labelSpeed30.AutoSize = true;
            this.labelSpeed30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelSpeed30.ForeColor = System.Drawing.Color.DarkRed;
            this.labelSpeed30.Location = new System.Drawing.Point(444, 458);
            this.labelSpeed30.Name = "labelSpeed30";
            this.labelSpeed30.Size = new System.Drawing.Size(23, 15);
            this.labelSpeed30.TabIndex = 34;
            this.labelSpeed30.Text = "30";
            // 
            // labelSpeed40
            // 
            this.labelSpeed40.AutoSize = true;
            this.labelSpeed40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelSpeed40.ForeColor = System.Drawing.Color.DarkRed;
            this.labelSpeed40.Location = new System.Drawing.Point(448, 431);
            this.labelSpeed40.Name = "labelSpeed40";
            this.labelSpeed40.Size = new System.Drawing.Size(23, 15);
            this.labelSpeed40.TabIndex = 35;
            this.labelSpeed40.Text = "40";
            // 
            // labelSpeed50
            // 
            this.labelSpeed50.AutoSize = true;
            this.labelSpeed50.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelSpeed50.ForeColor = System.Drawing.Color.DarkRed;
            this.labelSpeed50.Location = new System.Drawing.Point(457, 404);
            this.labelSpeed50.Name = "labelSpeed50";
            this.labelSpeed50.Size = new System.Drawing.Size(23, 15);
            this.labelSpeed50.TabIndex = 36;
            this.labelSpeed50.Text = "50";
            // 
            // labelSpeed60
            // 
            this.labelSpeed60.AutoSize = true;
            this.labelSpeed60.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelSpeed60.ForeColor = System.Drawing.Color.DarkRed;
            this.labelSpeed60.Location = new System.Drawing.Point(471, 377);
            this.labelSpeed60.Name = "labelSpeed60";
            this.labelSpeed60.Size = new System.Drawing.Size(23, 15);
            this.labelSpeed60.TabIndex = 37;
            this.labelSpeed60.Text = "60";
            // 
            // labelSpeed70
            // 
            this.labelSpeed70.AutoSize = true;
            this.labelSpeed70.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelSpeed70.ForeColor = System.Drawing.Color.DarkRed;
            this.labelSpeed70.Location = new System.Drawing.Point(495, 357);
            this.labelSpeed70.Name = "labelSpeed70";
            this.labelSpeed70.Size = new System.Drawing.Size(23, 15);
            this.labelSpeed70.TabIndex = 38;
            this.labelSpeed70.Text = "70";
            // 
            // labelSpeed80
            // 
            this.labelSpeed80.AutoSize = true;
            this.labelSpeed80.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelSpeed80.ForeColor = System.Drawing.Color.DarkRed;
            this.labelSpeed80.Location = new System.Drawing.Point(529, 339);
            this.labelSpeed80.Name = "labelSpeed80";
            this.labelSpeed80.Size = new System.Drawing.Size(23, 15);
            this.labelSpeed80.TabIndex = 39;
            this.labelSpeed80.Text = "80";
            // 
            // labelSpeed90
            // 
            this.labelSpeed90.AutoSize = true;
            this.labelSpeed90.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelSpeed90.ForeColor = System.Drawing.Color.DarkRed;
            this.labelSpeed90.Location = new System.Drawing.Point(572, 334);
            this.labelSpeed90.Name = "labelSpeed90";
            this.labelSpeed90.Size = new System.Drawing.Size(23, 15);
            this.labelSpeed90.TabIndex = 40;
            this.labelSpeed90.Text = "90";
            // 
            // labelSpeed100
            // 
            this.labelSpeed100.AutoSize = true;
            this.labelSpeed100.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelSpeed100.ForeColor = System.Drawing.Color.DarkRed;
            this.labelSpeed100.Location = new System.Drawing.Point(617, 339);
            this.labelSpeed100.Name = "labelSpeed100";
            this.labelSpeed100.Size = new System.Drawing.Size(31, 15);
            this.labelSpeed100.TabIndex = 41;
            this.labelSpeed100.Text = "100";
            // 
            // labelSpeed110
            // 
            this.labelSpeed110.AutoSize = true;
            this.labelSpeed110.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelSpeed110.ForeColor = System.Drawing.Color.DarkRed;
            this.labelSpeed110.Location = new System.Drawing.Point(648, 357);
            this.labelSpeed110.Name = "labelSpeed110";
            this.labelSpeed110.Size = new System.Drawing.Size(31, 15);
            this.labelSpeed110.TabIndex = 42;
            this.labelSpeed110.Text = "110";
            // 
            // labelSpeed120
            // 
            this.labelSpeed120.AutoSize = true;
            this.labelSpeed120.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelSpeed120.ForeColor = System.Drawing.Color.DarkRed;
            this.labelSpeed120.Location = new System.Drawing.Point(666, 377);
            this.labelSpeed120.Name = "labelSpeed120";
            this.labelSpeed120.Size = new System.Drawing.Size(31, 15);
            this.labelSpeed120.TabIndex = 43;
            this.labelSpeed120.Text = "120";
            // 
            // labelSpeed130
            // 
            this.labelSpeed130.AutoSize = true;
            this.labelSpeed130.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelSpeed130.ForeColor = System.Drawing.Color.DarkRed;
            this.labelSpeed130.Location = new System.Drawing.Point(684, 404);
            this.labelSpeed130.Name = "labelSpeed130";
            this.labelSpeed130.Size = new System.Drawing.Size(31, 15);
            this.labelSpeed130.TabIndex = 44;
            this.labelSpeed130.Text = "130";
            // 
            // labelSpeed140
            // 
            this.labelSpeed140.AutoSize = true;
            this.labelSpeed140.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelSpeed140.ForeColor = System.Drawing.Color.DarkRed;
            this.labelSpeed140.Location = new System.Drawing.Point(693, 431);
            this.labelSpeed140.Name = "labelSpeed140";
            this.labelSpeed140.Size = new System.Drawing.Size(31, 15);
            this.labelSpeed140.TabIndex = 45;
            this.labelSpeed140.Text = "140";
            // 
            // labelSpeed150
            // 
            this.labelSpeed150.AutoSize = true;
            this.labelSpeed150.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelSpeed150.ForeColor = System.Drawing.Color.DarkRed;
            this.labelSpeed150.Location = new System.Drawing.Point(695, 458);
            this.labelSpeed150.Name = "labelSpeed150";
            this.labelSpeed150.Size = new System.Drawing.Size(31, 15);
            this.labelSpeed150.TabIndex = 46;
            this.labelSpeed150.Text = "150";
            // 
            // labelSpeed160
            // 
            this.labelSpeed160.AutoSize = true;
            this.labelSpeed160.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelSpeed160.ForeColor = System.Drawing.Color.DarkRed;
            this.labelSpeed160.Location = new System.Drawing.Point(693, 487);
            this.labelSpeed160.Name = "labelSpeed160";
            this.labelSpeed160.Size = new System.Drawing.Size(31, 15);
            this.labelSpeed160.TabIndex = 47;
            this.labelSpeed160.Text = "160";
            // 
            // labelSpeed170
            // 
            this.labelSpeed170.AutoSize = true;
            this.labelSpeed170.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelSpeed170.ForeColor = System.Drawing.Color.DarkRed;
            this.labelSpeed170.Location = new System.Drawing.Point(684, 511);
            this.labelSpeed170.Name = "labelSpeed170";
            this.labelSpeed170.Size = new System.Drawing.Size(31, 15);
            this.labelSpeed170.TabIndex = 48;
            this.labelSpeed170.Text = "170";
            // 
            // labelSpeed180
            // 
            this.labelSpeed180.AutoSize = true;
            this.labelSpeed180.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelSpeed180.ForeColor = System.Drawing.Color.DarkRed;
            this.labelSpeed180.Location = new System.Drawing.Point(666, 536);
            this.labelSpeed180.Name = "labelSpeed180";
            this.labelSpeed180.Size = new System.Drawing.Size(31, 15);
            this.labelSpeed180.TabIndex = 49;
            this.labelSpeed180.Text = "180";
            // 
            // titleLabelSpeed
            // 
            this.titleLabelSpeed.AutoSize = true;
            this.titleLabelSpeed.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.titleLabelSpeed.Location = new System.Drawing.Point(495, 577);
            this.titleLabelSpeed.Name = "titleLabelSpeed";
            this.titleLabelSpeed.Size = new System.Drawing.Size(160, 34);
            this.titleLabelSpeed.TabIndex = 50;
            this.titleLabelSpeed.Text = "Изменение показаний \r\nспидометра:";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(884, 626);
            this.Controls.Add(this.titleLabelSpeed);
            this.Controls.Add(this.labelSpeed180);
            this.Controls.Add(this.labelSpeed170);
            this.Controls.Add(this.labelSpeed160);
            this.Controls.Add(this.labelSpeed150);
            this.Controls.Add(this.labelSpeed140);
            this.Controls.Add(this.labelSpeed130);
            this.Controls.Add(this.labelSpeed120);
            this.Controls.Add(this.labelSpeed110);
            this.Controls.Add(this.labelSpeed100);
            this.Controls.Add(this.labelSpeed90);
            this.Controls.Add(this.labelSpeed80);
            this.Controls.Add(this.labelSpeed70);
            this.Controls.Add(this.labelSpeed60);
            this.Controls.Add(this.labelSpeed50);
            this.Controls.Add(this.labelSpeed40);
            this.Controls.Add(this.labelSpeed30);
            this.Controls.Add(this.labelSpeed20);
            this.Controls.Add(this.labelSpeed10);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.listView2);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.Text = "Tyre calculator";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox newProfileComboBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox newWidthComboBox;
        private System.Windows.Forms.ComboBox newWheelSizeComboBox;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox profileComboBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox widthComboBox;
        private System.Windows.Forms.ComboBox wheelSizeComboBox;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.ComboBox yearComboBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox engineComboBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox modelComboBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox brandComboBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem settingslStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dictionarySetStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveConfStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem savePdftoolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label labelSpeed10;
        private System.Windows.Forms.Label labelSpeed20;
        private System.Windows.Forms.Label labelSpeed30;
        private System.Windows.Forms.Label labelSpeed40;
        private System.Windows.Forms.Label labelSpeed50;
        private System.Windows.Forms.Label labelSpeed60;
        private System.Windows.Forms.Label labelSpeed70;
        private System.Windows.Forms.Label labelSpeed80;
        private System.Windows.Forms.Label labelSpeed90;
        private System.Windows.Forms.Label labelSpeed100;
        private System.Windows.Forms.Label labelSpeed110;
        private System.Windows.Forms.Label labelSpeed120;
        private System.Windows.Forms.Label labelSpeed130;
        private System.Windows.Forms.Label labelSpeed140;
        private System.Windows.Forms.Label labelSpeed150;
        private System.Windows.Forms.Label labelSpeed160;
        private System.Windows.Forms.Label labelSpeed170;
        private System.Windows.Forms.Label labelSpeed180;
        private System.Windows.Forms.Label titleLabelSpeed;
    }
}

