﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace TyreCalculator.Model
{
    class ElementsToList
    {
        //string _xPath;
        //string _fileName;
        //string _elementName;
        //string _elementAtribValue;
        //XDocument _xDoc;

        //internal string XPath
        //{
        //    get { return _xPath; }
        //}

        //internal string FileName
        //{
        //    get { return _fileName; }
        //}

        //internal string ElementName
        //{
        //    get { return _elementName; }
        //}

        //internal string ElementAtribValue
        //{
        //    get { return _elementAtribValue; }
        //}

        //internal ElementsToList(string xPath, string fileName, string elementName)
        //{
        //    this._xPath = xPath;
        //    this._fileName = fileName;
        //    this._elementName = elementName;

        //}

        //internal List<string> GetElementsTo()
        //{
        //    _xDoc = XDocument.Load(_xPath + _fileName);
        //    List<string> list = new List<string> { };
        //    var items = from x in _xDoc.Root.Elements(_elementName)
        //                       select x;
        //    foreach (XElement Elemen in items)
        //    {
        //        list.Add(Elemen.Value);
        //    }
        //    return list;
        //}

    }
}
